import java.io.;
import java.util.;
import java.text.;
import java.math.;
import java.util.regex.;

public String sameEnds(String string)
            {
                int len=string.length();
                String fin=;
                String temp=;
                for(int i=0;ilen;i++)
                {
                    temp+=string.charAt(i);
                    int templen=temp.length();
                    if(ilen2 && temp.equals(string.substring(len-templen,len)))
                    fin=temp;
                }
            return fin;   
            }        
public class Solution {

    public static void main(String[] args) {
        
            String a;        
            Scanner s=new Scanner(System.in);
            a=s.nextInt();
            System.out.println(sameEnds(a));
            }
        }
    
   