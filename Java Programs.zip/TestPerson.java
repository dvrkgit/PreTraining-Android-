/* 
 * Superclass Person has name and address.
 */
public class Person {
   // private instance variables
   private String name, address;
   
   // Constructor
   public Person(String name, String address) {
      this.name = name;
      this.address = address;
   }
   
   // Getters and Setters
   public String getName() {
      return name;
   }
   public String getAddress() {
      return address;
   }
   public void setAddress(String address) {
      this.address = address;
   }
   
   // Describle itself
   public String toString() {
      return name + "(" + address + ")";
   }
}
/*
 * The Student class, subclass of Person.
 */
public class Student extends Person {
   // private instance variables
   private int year;   		// year student belongs 
   private String[] program; // program codes
   private double fee;     // fee 
     
   // Constructor
   public Student(String name, String address) {
      super(name, address);
      year = 0;
      program = new String[10];
      fee = new double[5];
   }
public String getProgram() {
      return program;
   }   

public void setProgram(String Program) {
      this.program = program;
   }

public int getname() {
      return name;
   }   

public int setName() {
      this.name=name;
   }
   
public double getFee() {
      return Fee;
   }   

public double setFee() {
      this.Fee=Fee;
   }

// Describe itself
   @Override
   public String toString() {
      return "Student: " + super.toString();
   }
   
  
/*
 * The Teacher class, subclass of Person.
 */
public class Staff extends Person {
   // private instance variables
   private double pay
   private String[] school; 
   
   // Constructor
   public Staff(double pay, String school) {
      super(name, address);
      pay = 0;
      school = new String[15];
   }
   
   // Describe itself
   @Override
   public String toString() {
      return "Teacher: " + super.toString();
   }
   
public String getSchool() {
      return school;
   }   

public String setSchool() {
      this.school=school;
   }
   
public double getPay() {
      return Pay;
   }   

public double setPay() {
      this.Pay=Pay;
   }
  
  